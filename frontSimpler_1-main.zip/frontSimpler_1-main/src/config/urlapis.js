//definimos la url de nuestro backend
export const urlBase = "http://192.168.3.122:3000"; //si me conecto a otra red, cambia la ip
export const login = `${urlBase}/user/login`;
//restarian las demas url
