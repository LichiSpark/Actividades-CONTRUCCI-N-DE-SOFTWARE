export const primaryColor = "#2A99F5";
export const secundaryColor = "#3B2AF5";
export const thirdColor = "#295AF5";
