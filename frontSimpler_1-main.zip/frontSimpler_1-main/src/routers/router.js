import Login from "../screens/login";

export default Router = () => {
  return <Login />;
};
