
import Router from "./src/routers/router";

export default function App() {
  return <Router />;
}
