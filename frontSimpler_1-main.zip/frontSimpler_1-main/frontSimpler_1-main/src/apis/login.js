import React, { useState } from 'react';
import { loginCheck } from '../config/urlapis';

const Login = () => {
  const [dni, setDni] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await loginCheck(dni, password);
      if (response.success) {
        setError('');
      } else {
        setError('Email o contraseña incorrectos');
      }
    } catch (err) {
      setError('Error en el servidor. Intenta de nuevo o más tarde.');
    }
  };

  return (
    <div>
      <form onSubmit={handleLogin}>
        <input 
          type="text" 
          value={dni} 
          onChange={(e) => setDni(e.target.value)} 
          placeholder="DNI" 
          required 
        />
        <input 
          type="password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          placeholder="Contraseña" 
          required 
        />
        <button type="submit">Login</button>
      </form>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};
export default Login;





