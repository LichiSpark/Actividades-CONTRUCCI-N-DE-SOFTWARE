import React from 'react';

const Home = ({ subjects }) => {
  return (
    <div>
      {subjects.map(subject => (
        <Card key={subject.id} subject={subject} />
      ))}
    </div>
  );
};

const Card = ({ subject }) => {
  return (
    <div className="card">
      <h3>{subject.name}</h3>
      <p>{subject.description}</p>
    </div>
  );
};

export default Home;
