import React, { useState } from 'react';

const NewSubject = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await saveSubjectApi({ name, description });
      alert('Materia guardada con éxito');
      setName('');
      setDescription('');
    } catch (err) {
      alert('Error al guardar la materia');
    }
  };

  return (
    <div>
      <h2>Nueva Materia</h2>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          placeholder="Nombre de la materia" 
          required 
        />
        <input 
          type="text" 
          value={description} 
          onChange={(e) => setDescription(e.target.value)} 
          placeholder="Descripción" 
          required 
        />
        <button type="submit">Guardar</button>
      </form>
    </div>
  );
};

// Función de simulación de guardar materia
const saveSubjectApi = (subject) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (subject.name && subject.description) {
        resolve();
      } else {
        reject();
      }
    }, 1000);
  });
};

export default NewSubject;
