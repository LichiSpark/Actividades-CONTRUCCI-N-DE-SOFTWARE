import { createNativeStackNavigator } from '@react-navigation/native-stack';


export default StackScreens = () => {
    const Stack = createNativeStackNavigator();

 return (
    <Stack.Navigator>
        <Stack.Screen component={subjects} name='' options={}/>
        <Stack.Screen component={subjects} name='' options={}/>
        <Stack.Screen component={subjects} name='' options={}/>
    </Stack.Navigator>
 )
}